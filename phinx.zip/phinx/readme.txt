#https://github.com/fzaninotto/Faker

.\php\php.exe .\composer.phar config --global disable-tls true
.\php\php.exe .\composer.phar config --global secure-http false
 
.\php\php.exe .\composer.phar require robmorgan/phinx
.\php\php.exe .\composer.phar require fzaninotto/faker
.\php\php.exe .\composer.phar update

vendor/bin/phinx init

# Edit .\phinx\phinx.php" to fit




# https://book.cakephp.org/phinx/0/en/migrations.html
# https://book.cakephp.org/phinx/0/en/seeding.html#creating-a-new-seed-class
# https://book.cakephp.org/phinx/0/en/configuration.html#id3