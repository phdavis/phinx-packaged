#cd C:\Users\phdavis\Desktop\phinx

#.\php\php.exe .\composer.phar config --global disable-tls true
#.\php\php.exe .\composer.phar config --global secure-http false
 
#.\php\php.exe .\composer.phar require robmorgan/phinx
#.\php\php.exe .\composer.phar require fzaninotto/faker
.#\php\php.exe .\composer.phar update